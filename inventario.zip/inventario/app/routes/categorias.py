from flask import Blueprint, render_template, request, redirect, url_for
from app import db
from app.models import Categoria
from sqlalchemy.exc import IntegrityError

categorias_bp = Blueprint('categorias', __name__, url_prefix='/categorias')



categorias_bp = Blueprint("categorias", __name__, template_folder="templates", url_prefix="/categorias")

@categorias_bp.route("/", methods=["GET"])
def lista():
    q = request.args.get("q", "")
    if q:
        categorias = Categoria.query.filter(Categoria.Nombre.ilike(f"%{q}%")).order_by(Categoria.Nombre).all()
    else:
        categorias = Categoria.query.order_by(Categoria.Nombre).all()
    return render_template("categorias/lista.html", categorias=categorias, q=q)

@categorias_bp.route("/crear", methods=["GET", "POST"])
def crear():
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        descripcion = request.form.get("descripcion", "").strip()
        if not nombre:
            flash("El nombre es obligatorio.", "danger")
            return render_template("categorias/form.html", accion="Crear", categoria={})
        nueva = Categoria(Nombre=nombre, Descripcion=descripcion)
        db.session.add(nueva)
        try:
            db.session.commit()
            flash("Categoría creada correctamente.", "success")
            return redirect(url_for("categorias.lista"))
        except IntegrityError:
            db.session.rollback()
            flash("Ya existe una categoría con ese nombre.", "warning")
            return render_template("categorias/form.html", accion="Crear", categoria={"Nombre": nombre, "Descripcion": descripcion})
    return render_template("categorias/form.html", accion="Crear", categoria={})

@categorias_bp.route("/editar/<int:id>", methods=["GET", "POST"])
def editar(id):
    categoria = Categoria.query.get_or_404(id)
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        descripcion = request.form.get("descripcion", "").strip()
        if not nombre:
            flash("El nombre es obligatorio.", "danger")
            return render_template("categorias/form.html", accion="Editar", categoria=categoria)
        categoria.Nombre = nombre
        categoria.Descripcion = descripcion
        try:
            db.session.commit()
            flash("Categoría actualizada.", "success")
            return redirect(url_for("categorias.lista"))
        except IntegrityError:
            db.session.rollback()
            flash("Ya existe otra categoría con ese nombre.", "warning")
            return render_template("categorias/form.html", accion="Editar", categoria=categoria)
    return render_template("categorias/form.html", accion="Editar", categoria=categoria)

@categorias_bp.route("/eliminar/<int:id>", methods=["POST"])
@categorias_bp.route('/categorias/eliminar/<int:id>')

def eliminar_categoria(id):
    categoria = Categoria.query.get(id)
    if categoria:
        db.session.delete(categoria)  # ❌ Elimina la fila de la base
        db.session.commit()
    return redirect(url_for('categorias'))

